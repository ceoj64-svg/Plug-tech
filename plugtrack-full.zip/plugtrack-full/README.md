# PlugTrack – full package

## 1. Run the online server (cloud sync + AI link reader)
    npm install
    set JWT_SECRET=a-long-random-text          (Windows)  /  export JWT_SECRET=...  (Mac/Linux)
    set ANTHROPIC_API_KEY=sk-ant-...           (optional – turns on the AI link reader)
    npm start                                  -> http://localhost:3000
Deploy to Render, Railway or any VPS with Node 18+. Keep db.json on persistent disk.
Use HTTPS in production.

## 2. Build the Windows program (.exe)
Edit config.json: put your server address in "serverUrl" (e.g. "https://plugtrack.example.com")
for cloud sync, or leave it empty for fully offline use. Then, on a Windows PC:
    npm install
    npm run build:win        -> installer appears in /dist
    npm run desktop          -> test without building

## Notes
- The AI reader fetches the Shein page from your server. Shein may block automated requests or
  load prices with JavaScript; when that happens the item name still comes from the link and you
  type the price. Check Shein's terms / affiliate programme before relying on it.
- Without ANTHROPIC_API_KEY the reader uses the page's own meta tags only.
- Prices are converted to USD using the exchange rates in Settings.
