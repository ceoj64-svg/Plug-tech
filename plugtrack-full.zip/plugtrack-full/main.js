// Windows desktop wrapper. If config.json has a serverUrl, the app opens your
// online server (cloud sync on). If empty, it runs fully offline from ./public.
const { app, BrowserWindow } = require('electron');
const path = require('path'), fs = require('fs');
function createWindow() {
  const w = new BrowserWindow({ width: 1280, height: 820, title: 'PlugTrack', autoHideMenuBar: true });
  let url = '';
  try { url = JSON.parse(fs.readFileSync(path.join(__dirname, 'config.json'))).serverUrl; } catch (e) {}
  url ? w.loadURL(url) : w.loadFile(path.join(__dirname, 'public', 'index.html'));
}
app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
