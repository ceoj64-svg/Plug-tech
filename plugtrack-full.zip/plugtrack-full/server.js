const express = require('express'), fs = require('fs'), path = require('path');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken');
const app = express(), DB = process.env.DB_FILE || 'db.json', SECRET = process.env.JWT_SECRET || 'change-me-now';
app.use(express.json({ limit: '20mb' }));
const load = () => { try { return JSON.parse(fs.readFileSync(DB)); } catch (e) { return { users: {}, data: {} }; } };
const write = d => fs.writeFileSync(DB, JSON.stringify(d));
const guard = (q, s, n) => { try { q.u = jwt.verify((q.headers.authorization || '').slice(7), SECRET).e; n(); } catch (e) { s.status(401).json({ error: 'Not signed in' }); } };
const token = e => jwt.sign({ e }, SECRET, { expiresIn: '60d' });
app.get('/api/ping', (q, s) => s.json({ ok: 1 }));
app.post('/api/register', async (q, s) => {
  const e = (q.body.email || '').toLowerCase().trim(), p = q.body.password || '';
  if (!/^[^@\s]+@gmail\.com$/.test(e) || p.length < 6) return s.status(400).json({ error: 'Use a Gmail address and a password of 6+ characters' });
  const d = load(); if (d.users[e]) return s.status(400).json({ error: 'Account already exists' });
  d.users[e] = await bcrypt.hash(p, 10); write(d); s.json({ token: token(e) });
});
app.post('/api/login', async (q, s) => {
  const e = (q.body.email || '').toLowerCase().trim(), d = load();
  if (!d.users[e] || !(await bcrypt.compare(q.body.password || '', d.users[e]))) return s.status(400).json({ error: 'Wrong email or password' });
  s.json({ token: token(e) });
});
app.get('/api/data', guard, (q, s) => s.json(load().data[q.u] || null));
app.put('/api/data', guard, (q, s) => { const d = load(); d.data[q.u] = q.body; write(d); s.json({ ok: 1 }); });

// ---- AI link reader ----
const okHost = h => /(^|\.)shein\.[a-z.]+$/.test(h);
const meta = (h, p) => { const m = h.match(new RegExp('<meta[^>]+(?:property|name)=["\']' + p + '["\'][^>]*content=["\']([^"\']*)["\']', 'i')) || h.match(new RegExp('<meta[^>]+content=["\']([^"\']*)["\'][^>]*(?:property|name)=["\']' + p + '["\']', 'i')); return m ? m[1] : ''; };
app.post('/api/read-link', guard, async (q, s) => {
  try {
    const u = new URL(q.body.url); if (!okHost(u.hostname)) return s.status(400).json({ error: 'Only Shein links are allowed' });
    const r = await fetch(u, { redirect: 'follow', headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36', 'Accept-Language': 'en' } });
    if (!okHost(new URL(r.url).hostname)) return s.status(400).json({ error: 'Redirected away from Shein' });
    const html = (await r.text()).slice(0, 800000);
    let out = { name: meta(html, 'og:title'), image: meta(html, 'og:image'), price: parseFloat(meta(html, 'product:price:amount') || (html.match(/"price"\s*:\s*"?([\d.]+)/) || [])[1]) || 0, currency: meta(html, 'product:price:currency') || 'USD', source: 'page' };
    if (process.env.ANTHROPIC_API_KEY) {
      const text = html.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/g, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').slice(0, 6000);
      const a = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
        body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5', max_tokens: 300, messages: [{ role: 'user', content: 'From this Shein product page extract JSON only: {"name":string,"price":number,"currency":string}. Page title: ' + out.name + '\nPage text: ' + text }] }) });
      const j = await a.json(); const t = (j.content && j.content[0] && j.content[0].text) || '';
      try { const x = JSON.parse(t.replace(/```json|```/g, '').trim()); out = { ...out, name: x.name || out.name, price: x.price || out.price, currency: x.currency || out.currency, source: 'ai' }; } catch (e) {}
    }
    s.json(out);
  } catch (e) { s.status(500).json({ error: 'Could not read link' }); }
});
app.use(express.static(path.join(__dirname, 'public')));
app.listen(process.env.PORT || 3000, () => console.log('PlugTrack running'));
